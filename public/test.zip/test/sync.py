# -*- coding: utf-8 -*-

from ftplib import FTP
import os
import hashlib
import ftputil
import requests
import sys, os, os.path, shutil
from PyQt4 import QtGui, QtCore

User_email = raw_input ("Enter email \n") 
User_password = raw_input ("Enter password \n")

SERVER_IP = "pegas.beget.ru"
USER = 'melnik5g_andrey'
PASS = 'DENVER'
REMOTE_FOLDER = '/files/'
LOCAL_FOLDER = os.path.expanduser('~/Dronbox')
host = ftputil.FTPHost(SERVER_IP,USER,PASS)
DATA = {
    'email' : User_email,
    'password_digest' : User_password,
}
URL = "http://syncapp.x2z54.locum.ru/sessions"

class BoxLayout(QtGui.QWidget):
    def __init__(self, parent=None):
        QtGui.QWidget.__init__(self, parent)

        self.setWindowTitle('Sync app') 

        buttonFROM = QtGui.QPushButton("From ftp") #создаём кнопку

        self.connect(buttonFROM, QtCore.SIGNAL('clicked()'), fromFTP)

        buttonON = QtGui.QPushButton("On ftp") #создаём кнопку

        self.connect(buttonON, QtCore.SIGNAL('clicked()'), onFTP)
        

        hbox = QtGui.QHBoxLayout() #Создаем горизонтальный макет компоновки. Затем добавляем коэффициент притяжения и 2 кнопки.
        hbox.addStretch(1)
        hbox.addWidget(buttonFROM)
        hbox.addWidget(buttonON)

        vbox = QtGui.QVBoxLayout() #Что бы разместить виджеты в нужном формате, мы размещаем вертикальный макет в горизонтальном.
        vbox.addStretch(1)
        vbox.addLayout(hbox)

        self.setLayout(vbox) #И в заключении мы определяем основную компоновку.

        self.resize(300, 150)


def fromFTP():
    print 'Connect to Server'
    ftp = FTP(SERVER_IP, USER, PASS)
    print 'Go to the server directory  ' + REMOTE_FOLDER
    ftp.cwd(REMOTE_FOLDER) #Определяем текущие папки
    print 'Go to the client directory  ' + LOCAL_FOLDER
    os.chdir(LOCAL_FOLDER)
    remote_files = set(ftp.nlst()) #Получаем списки файлов
    local_files = set(os.listdir(os.curdir))
    for fname in remote_files:
        fullNameServer = host.path.join(REMOTE_FOLDER, fname) #Определяем путь до файлов
        file = open(fname, 'wb')
        ftp.retrbinary('RETR ' + fname, file.write);
        file.close()
    ftp.close()
    print 'Synchronization completed successfully'

def onFTP():
    #dateServerFile = 0
    #dateHomeFile = 0
    ftp = FTP(SERVER_IP,USER,PASS) # connect to host, default port
    ftp.cwd(REMOTE_FOLDER) #Определяем текущие папки
    os.chdir(LOCAL_FOLDER)
    remote_files = set(ftp.nlst()) #Получаем списки файлов
    local_files = set(os.listdir(os.curdir))

    for fname in local_files:
        fullNameServer = host.path.join(REMOTE_FOLDER, fname) #Определяем путь до файлов
        fullNameHome = os.path.join(LOCAL_FOLDER, fname)
        #if os.path.exists(fullNameHome): #Если файл найден заносив время в переменную
            #dateHomeFile = os.path.getmtime(fullNameHome)

        #if host.path.exists(fullNameServer):
            #dateServerFile = host.path.getmtime(fullNameServer)
        #else:
        ftp.storbinary('STOR ' + fname, open(fname, 'rb')) # Если файла на сервере нету, загружаем его

        #if os.path.isfile(fullNameHome) and host.path.isfile(fullNameServer):
            #if dateServerFile < dateHomeFile:
                #ftp.storbinary('STOR ' + fname, open(fname, 'rb'))

def auth(url,data=None):
    r = requests.post(url,data=data,allow_redirects=False)
    return r.status_code

status = auth(URL,data=DATA)
print status
if status == 302: #Если пользователь авторизовался
    print "\n\n\nWelcome " + User_email
    REMOTE_FOLDER = host.path.join(REMOTE_FOLDER, User_email)

    if not os.path.exists(LOCAL_FOLDER):
        os.makedirs(LOCAL_FOLDER)

    if not host.path.exists(REMOTE_FOLDER):
        try:
            host.mkdir(REMOTE_FOLDER)
        except OSError:
            pass

    app = QtGui.QApplication(sys.argv)
    qb = BoxLayout()
    qb.show()
    sys.exit(app.exec_())
else:
    print "Access denied"
    






