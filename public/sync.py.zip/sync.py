# coding: utf-8

from ftplib import FTP
import os
import hashlib
import ftputil
import requests

User_email = raw_input ("Enter email \n") #Запрос логина и пароля
User_password = raw_input ("Enter password \n")

SERVER_IP = "pegas.beget.ru"
USER = 'melnik5g_andrey'
PASS = 'DENVER'
REMOTE_FOLDER = '/files/'
LOCAL_FOLDER = os.path.expanduser('~/Dronbox')
host = ftputil.FTPHost(SERVER_IP,USER,PASS)
DATA = {
    'email' : User_email,
    'password_digest' : User_password,
}
URL = "http://syncapp.x2z54.locum.ru/sessions"

def fromFTP(ftp_host,ftp_user = None, ftp_password = None):
    print 'Подключение к фтп'
    ftp = FTP(ftp_host, ftp_user, ftp_password)
    print 'Переходим в директорию сервера  ' + REMOTE_FOLDER
    ftp.cwd(REMOTE_FOLDER) #Определяем текущие папки
    print 'Переходим в директорию клиента  ' + LOCAL_FOLDER
    os.chdir(LOCAL_FOLDER)
    remote_files = set(ftp.nlst()) #Получаем списки файлов
    local_files = set(os.listdir(os.curdir))
    for fname in remote_files:
        fullNameServer = host.path.join(REMOTE_FOLDER, fname) #Определяем путь до файлов
        file = open(fname, 'wb')
        ftp.retrbinary('RETR ' + fname, file.write);
        file.close()
    ftp.close()

def onFTP(ftp_host, ftp_user = None, ftp_password = None):
    #dateServerFile = 0
    #dateHomeFile = 0
    ftp = FTP(ftp_host, ftp_user, ftp_password) # connect to host, default port
    ftp.cwd(REMOTE_FOLDER) #Определяем текущие папки
    os.chdir(LOCAL_FOLDER)
    remote_files = set(ftp.nlst()) #Получаем списки файлов
    local_files = set(os.listdir(os.curdir))

    for fname in local_files:
        fullNameServer = host.path.join(REMOTE_FOLDER, fname) #Определяем путь до файлов
        fullNameHome = os.path.join(LOCAL_FOLDER, fname)
        #if os.path.exists(fullNameHome): #Если файл найден заносив время в переменную
            #dateHomeFile = os.path.getmtime(fullNameHome)

        #if host.path.exists(fullNameServer):
            #dateServerFile = host.path.getmtime(fullNameServer)
        #else:
        ftp.storbinary('STOR ' + fname, open(fname, 'rb')) # Если файла на сервере нету, загружаем его

        #if os.path.isfile(fullNameHome) and host.path.isfile(fullNameServer):
            #if dateServerFile < dateHomeFile:
                #ftp.storbinary('STOR ' + fname, open(fname, 'rb'))

def auth(url,data=None):
    r = requests.post(url,data=data)
    return r.status_code

status = auth(URL,data=DATA)

if status == 302: #Если пользователь авторизовался
    print "\n\n\nWelcome " + User_email
    REMOTE_FOLDER = host.path.join(REMOTE_FOLDER, User_email)

    if not os.path.exists(LOCAL_FOLDER):
        os.makedirs(LOCAL_FOLDER)

    if not host.path.exists(REMOTE_FOLDER):
        try:
            host.mkdir(REMOTE_FOLDER)
        except OSError:
            pass

    print "Начало синхронизации...\n\n\n"
    onFTP(SERVER_IP, ftp_user = USER, ftp_password = PASS)
    fromFTP(SERVER_IP, ftp_user = USER, ftp_password = PASS)
else:
    print "Access denied"


